# Joshua Teye Academic Website

This is a free static academic website prepared for GitHub Pages.

## Files
- `index.html` — full website
- `style.css` — responsive styling
- `Joshua_Teye_CV.pdf` — curriculum vitae

## Publish free with GitHub Pages
1. Create a GitHub account if you do not already have one.
2. Create a new public repository named: `YOURUSERNAME.github.io`
3. Upload `index.html`, `style.css`, and `Joshua_Teye_CV.pdf`.
4. Open repository **Settings → Pages**.
5. Under **Build and deployment**, choose **Deploy from a branch**.
6. Select the `main` branch and `/ (root)`, then save.
7. Your site will use the address: `https://YOURUSERNAME.github.io`

## Add a professional photo later
Replace the `.portrait-placeholder` block in `index.html` with:

    <img class="profile-photo" src="photo.jpg" alt="Joshua Teye">

Then add `photo.jpg` to the same folder.

You can add this CSS if desired:

    .profile-photo {
      width: 100%;
      aspect-ratio: 4 / 5;
      object-fit: cover;
      border-radius: 12px;
      display: block;
    }

## Suggested future additions
- Downloadable job market paper
- Google Scholar link
- ORCID link
- Research paper PDFs
- Teaching statement
- Research statement
- Custom domain
